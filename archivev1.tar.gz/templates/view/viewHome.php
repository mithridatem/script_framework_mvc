<?php ob_start() ?>
<h1>Page d'Accueil</h1>
<h2>Bienvenue</h2>
<?php $body = ob_get_clean() ?>
