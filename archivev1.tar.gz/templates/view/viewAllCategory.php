<?php ob_start() ?>
<h1>Page d'Accueil</h1>
<h2>Bienvenue</h2>
<?php foreach($data as $cat) :?>

<p><?="Nom de la catégorie : " .  $cat->getName()?> </p> 
<?php endforeach ?>
<?php $body = ob_get_clean() ?>
