<?php

namespace App\Controller;

use App\controller\AbstractController;
use App\Repository\ExempleRepository;


class HomeController extends AbstractController {

    private ExempleRepository $exempleRepository;
   
    public function __construct()
    {
        $this->exempleRepository = new ExempleRepository();
    }
    public function home() {
        return $this->render("view/viewHome", "home");
    }

    public function test() {
        $cat = $this->exempleRepository->findAll();
        echo "<pre>";
        var_dump($cat);
        echo "</pre>";
        die;
    }

    public function showAllCategory() {
        $categories = $this->exempleRepository->findAll();
        return $this->render("view/viewallCategory", "Categories", $categories);
    }
}
