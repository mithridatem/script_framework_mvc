<?php

namespace App\Repository;

use App\Model\AbstractModel;
use App\Model\Exemple;
use App\Model\Category;
use App\Repository\AbstractRepository;

class ExempleRepository extends AbstractRepository
{
    public function __construct()
    {
        parent::__construct();
    }

    public function find(int $id): Category
    {
        $sql = "SELECT c.id_category AS id, c.name FROM category AS c WHERE c.id_category = ?";
        $request = $this->bdd->prepare($sql);
        $request->bindParam(1, $id, \PDO::PARAM_INT);
        $request->execute();
        $request->setFetchMode(\PDO::FETCH_CLASS, Category::class);
        return $request->fetch();
    }

    public function findAll(): array
    {
        $sql = "SELECT c.id_category AS id, c.name FROM category AS c";
        $request = $this->bdd->prepare($sql);
        $request->execute();
        $request->setFetchMode(\PDO::FETCH_CLASS, Category::class);
        return $request->fetchAll();
    }

    public function save(AbstractModel $model): Exemple
    {
        return new Exemple();
    }

    public function update(int $id, AbstractModel $model): Exemple
    {
        return $model;
    }

    public function delete(int $id): void {}
}
