<?php

namespace App\Repository;

use App\Model\AbstractModel;
use App\Utils\Bdd;

abstract class AbstractRepository
{

    protected \PDO $bdd;

    protected function __construct()
    {
        $this->bdd = (new Bdd())->connect();
    }

    abstract public function find(int $id): AbstractModel;
    abstract public function findAll(): array;
    abstract public function save(AbstractModel $model): AbstractModel;
    abstract public function update(int $id, AbstractModel $model): AbstractModel;
    abstract public function delete(int $id): void;
}
