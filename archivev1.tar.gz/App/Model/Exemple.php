<?php

namespace App\Model;

use App\Model\AbastractModel;

class Exemple extends AbstractModel{}
