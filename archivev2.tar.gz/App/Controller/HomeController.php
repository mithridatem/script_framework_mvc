<?php

namespace App\Controller;

use App\controller\AbstractController;

class HomeController extends AbstractController {

    public function home() {
        return $this->render("view/viewHome", "home");
    }
}
