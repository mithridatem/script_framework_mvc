<?php

namespace App\controller;

abstract class AbstractController
{

    public function render(string $view, string $title = "titre", mixed $data = [], $error = [])
    {

        if (file_exists("./templates/" . $view . ".php")) {
            include "./templates/header.php";
            include "./templates/footer.php";
            include "./templates/" . $view . ".php";
            include "./templates/base.php";
        } else {
            include "./templates/view/view404.php";
        }
    }


    public function json(mixed $data, int $httpCode = 200)
    {
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        http_response_code($httpCode);
        echo json_encode($data);
    }

    //Méthode qui convertie une chaine de caractéres en UTF-8
    public function utf8Encode(string $str): string
    {

        return mb_convert_encoding(
            $str,
            "UTF-8",
            mb_detect_encoding($str)
        );
    }

    //Méthode qui nettoie une chaine de caractéres
    public function sanitize(string $input): string
    {
        $input = trim($input);
        $input = strip_tags($input);
        $input = htmlspecialchars($input, ENT_NOQUOTES);
        return $input;
    }

    //Méthode qui nettoie un tableau de données
    public function sanitizeArray(array $data): array
    {
        $cleanData = [];
        foreach ($data as $key => $value) {
            $cleanData[$key] = self::sanitize($value);
        }
        return $cleanData;
    }
}
