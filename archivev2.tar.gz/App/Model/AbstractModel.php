<?php

namespace App\Model;

abstract class AbstractModel {

     public function hydrate(array $data) :self {
        foreach ($data as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (method_exists($this, $method)) {
                $this->$method($value);
            }
        }
        return $this;
    }

    //Méthode qui deshydrate l'objet User en tableau
    public function toArray() :array {
        $user = [];
        foreach ($this as $key => $value) {
            $method = 'get' . ucfirst($key);
            if (method_exists($this, $method)) {
                $user[$key] = $this->$method();
            }
        }
        return $user;         
    }
}
