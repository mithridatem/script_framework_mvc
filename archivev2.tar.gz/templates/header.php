<?php ob_start() ?>
<h1>Menu</h1>
<?php $header = ob_get_clean() ?>
