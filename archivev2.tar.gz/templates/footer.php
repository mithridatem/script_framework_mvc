<?php ob_start() ?>
<h1>Pied de page</h1>
<?php $footer = ob_get_clean() ?>
