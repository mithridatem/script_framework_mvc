<?php

namespace App\Model;

/**
 * classe Abstraite pour chaque Model
 * */
abstract class AbstractModel {}
