<?php

namespace App\Repository;

use App\Model\AbstractModel;
use App\Utils\Bdd;
/**
 * classe Abstraite pour chaque Repository
 * @method AbstractModel find(int $id) 
 * @method array findAll() 
 * @method AbstractModel save(AbstractModel $model) 
 * @method AbstractModel update(int $id, AbstractModel $model) 
 * @method void delete(int $id) 
 * */
abstract class AbstractRepository
{

    protected \PDO $bdd;

    protected function __construct()
    {
        $this->bdd = (new Bdd())->connect();
    }

    abstract public function find(int $id): AbstractModel;
    abstract public function findAll(): array;
    abstract public function save(AbstractModel $model): AbstractModel;
    abstract public function update(int $id, AbstractModel $model): AbstractModel;
    abstract public function delete(int $id): void;
}
