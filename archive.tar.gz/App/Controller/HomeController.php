<?php

namespace App\Controller;

use App\controller\AbstractController;


class HomeController extends AbstractController {

    public function home() {
        return $this->render("view/viewHome", "home");
    }

    public function error404() {
        return $this->render("view/view404", "404");
    }
}
