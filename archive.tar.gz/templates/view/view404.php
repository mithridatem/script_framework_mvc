<?php ob_start() ?>
<h1>Error 404 Page not Found</h1>
<?php $body = ob_get_clean() ?>
