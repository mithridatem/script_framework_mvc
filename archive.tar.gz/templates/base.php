<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/assets/styles/main.css">
    <script src="./public/assets/scripts/main.js" async></script>
    <title><?= $title ?></title>
</head>

<body>
    <!-- zone header -->
    <?= $header ?>
    <!-- zone body -->
    <?= $body ?>
    <!-- zone footer-->
    <?= $footer ?>
</body>

</html>
